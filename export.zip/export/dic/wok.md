# wok

## Meaning

1

## Candidates

|Word|Score|
|:-:|:-:|
|wok|0.380580|
|ton|0.380478|
|don|0.380453|
|won|0.380453|
|xon|0.380453|
|son|0.380449|
|wot|0.380438|
|wos|0.380433|
|wod|0.380429|
|woc|0.380410|

## Origins

Weight sum: 4307.36075
|ISO 639-1|Weight|Regular weight|Origin word|IPA|Loanword|
|:-:|:-:|:-:|:-:|:-:|:-:|
|zh|1020.85|0.2370|一|i⁵⁵|i|
|en|818.9|0.1901|one|wɒn|won|
|es|500.45|0.1162|uno|uno|uno|
|hi|489.65|0.1137|एक|eːk|ek|
|bn|246.9|0.0573|এক|æːk|ak|
|pt|240|0.0557|um|ũ|u|
|ru|205.75|0.0478|один|ɐdʲin|adin|
|fr|176.95|0.0411|un|œ̃||
|ar|137|0.0318|واحد|waːħid|waxid|
|ja|126.26075|0.0293|いち|it͡ɕi|itci|
|id|121.3|0.0282|satu|satu|satu|
|ur|119.8|0.0278|ایک|ek|ek|
|de|103.55|0.0240|eins|aɪ̯ns|ains|
