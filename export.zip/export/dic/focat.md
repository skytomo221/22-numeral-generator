# focat

## Meaning

4

## Candidates

|Word|Score|
|:-:|:-:|
|focat|1.260278|
|carat|1.142436|
|watar|1.115500|
|catir|1.071355|
|focar|1.040620|
|cicat|1.034128|
|wacar|1.004022|
|katar|0.984677|
|catiz|0.975769|
|catit|0.975532|

## Origins

Weight sum: 4307.36075
|ISO 639-1|Weight|Regular weight|Origin word|IPA|Loanword|
|:-:|:-:|:-:|:-:|:-:|:-:|
|zh|1020.85|0.2370|四|sz̩²¹³|sz|
|en|818.9|0.1901|four|fɔː|fo|
|es|500.45|0.1162|cuatro|kwatɾo|kwatro|
|hi|489.65|0.1137|चार|t͡ʃɑːɾ|tcar|
|bn|246.9|0.0573|চার|ʈʃar|tcar|
|pt|240|0.0557|quatro|kwatɾu|kwatru|
|ru|205.75|0.0478|четыре|t͡ɕɪtɨrʲe|tcitire|
|fr|176.95|0.0411|quatre|kat|kat|
|ar|137|0.0318|أربعة|ʔarbaʕa|arbaua|
|ja|126.26075|0.0293|し|ɕi|ci|
|id|121.3|0.0282|empat|empat|empat|
|ur|119.8|0.0278|چار|t͡ʃɑːɾ|tcar|
|de|103.55|0.0240|vier|fiːr|fir|
