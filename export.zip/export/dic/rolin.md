# rolin

## Meaning

0

## Candidates

|Word|Score|
|:-:|:-:|
|rolin|1.462478|
|lirol|1.415479|
|liron|1.359299|
|liror|1.359185|
|culir|1.340176|
|zinun|1.339999|
|lirer|1.339046|
|lirun|1.308015|
|ronin|1.283766|
|ziner|1.280564|

## Origins

Weight sum: 4307.36075
|ISO 639-1|Weight|Regular weight|Origin word|IPA|Loanword|
|:-:|:-:|:-:|:-:|:-:|:-:|
|zh|1020.85|0.2370|零|liŋ²⁴|lin|
|en|818.9|0.1901|zero|ˈzɪə.ɹəʊ|zirou|
|es|500.45|0.1162|cero|θeɾo|sero|
|hi|489.65|0.1137|शून्य|ʃuːnja|cunya|
|bn|246.9|0.0573|শূন্য|ʃunyo|cunio|
|pt|240|0.0557|zero|zɛɾu|zeru|
|ru|205.75|0.0478|нуль|nulʲ|nul|
|fr|176.95|0.0411|zéro|zeʁo|zero|
|ar|137|0.0318|صفر|sˤafar|safar|
|ja|126.26075|0.0293|れい|ɾe̞ː|re|
|id|121.3|0.0282|nol|nol|nol|
|ur|119.8|0.0278|صفر|sifr|sifr|
|de|103.55|0.0240|null|nʊl|nul|
