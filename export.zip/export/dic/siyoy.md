# siyoy

## Meaning

6

## Candidates

|Word|Score|
|:-:|:-:|
|siyoy|1.114923|
|siyot|1.000481|
|siyoh|1.000453|
|siyom|1.000368|
|siyos|1.000339|
|sesit|0.997405|
|seyoy|0.988589|
|sisah|0.985887|
|sesiy|0.965722|
|sesih|0.965541|

## Origins

Weight sum: 4307.36075
|ISO 639-1|Weight|Regular weight|Origin word|IPA|Loanword|
|:-:|:-:|:-:|:-:|:-:|:-:|
|zh|1020.85|0.2370|六|ljoʊ̯⁵¹|lyou|
|en|818.9|0.1901|six|sɪks|siks|
|es|500.45|0.1162|seis|seis|seis|
|hi|489.65|0.1137|छह|t͡ʃʰəɦ|tcah|
|bn|246.9|0.0573|ছয়|tʃʰɔj|tcoy|
|pt|240|0.0557|seis|sejs|seys|
|ru|205.75|0.0478|шесть|ʂɛsʲtʲ|cest|
|fr|176.95|0.0411|six|si|si|
|ar|137|0.0318|ستة|sitta|sitta|
|ja|126.26075|0.0293|ろく|ɾo̞kɯ̟ᵝ|roku|
|id|121.3|0.0282|enam|enam|enam|
|ur|119.8|0.0278|چھہ|t͡ʃʰeː|tce|
|de|103.55|0.0240|sechs|zɛks|zeks|
