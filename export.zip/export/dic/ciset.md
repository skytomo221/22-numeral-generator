# ciset

## Meaning

7

## Candidates

|Word|Score|
|:-:|:-:|
|ciset|1.408244|
|saten|1.327147|
|citen|1.286320|
|setat|1.273281|
|civet|1.257008|
|saset|1.222278|
|sevet|1.200373|
|sesat|1.190380|
|caten|1.179397|
|sevat|1.175426|

## Origins

Weight sum: 4307.36075
|ISO 639-1|Weight|Regular weight|Origin word|IPA|Loanword|
|:-:|:-:|:-:|:-:|:-:|:-:|
|zh|1020.85|0.2370|七|t͡ɕʰi⁵⁵|tci|
|en|818.9|0.1901|seven|sɛvən|seven|
|es|500.45|0.1162|siete|sjete|syete|
|hi|489.65|0.1137|सात|sɑːt̪|sat|
|bn|246.9|0.0573|সাত|ʃat|cat|
|pt|240|0.0557|sete|sɛte|sete|
|ru|205.75|0.0478|семь|sʲemʲ|sem|
|fr|176.95|0.0411|trois|tʁwa|trwa|
|ar|137|0.0318|سبعة|sabʕa|sabua|
|ja|126.26075|0.0293|しち|ɕi̥t͡ɕi|citci|
|id|121.3|0.0282|tujuh|tujuh|tuyuh|
|ur|119.8|0.0278|سات|sɑːt̪|sat|
|de|103.55|0.0240|sieben|ziːbm̩|zibm|
