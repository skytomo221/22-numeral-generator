# novin

## Meaning

9

## Candidates

|Word|Score|
|:-:|:-:|
|novin|1.089200|
|nanot|0.994168|
|nanol|0.994120|
|nanon|0.994120|
|nonan|0.994120|
|tinol|0.945856|
|tinon|0.945856|
|tinot|0.945856|
|binol|0.938570|
|binon|0.938570|

## Origins

Weight sum: 4307.36075
|ISO 639-1|Weight|Regular weight|Origin word|IPA|Loanword|
|:-:|:-:|:-:|:-:|:-:|:-:|
|zh|1020.85|0.2370|九|t͡ɕiou⁵¹|tciou|
|en|818.9|0.1901|nine|naɪn|nain|
|es|500.45|0.1162|nueve|nwebe|nwebe|
|hi|489.65|0.1137|नौ|nɔː|no|
|bn|246.9|0.0573|নয়|noy|noi|
|pt|240|0.0557|nove|nɔvi|novi|
|ru|205.75|0.0478|девять|dʲevʲɪtʲ|devit|
|fr|176.95|0.0411|neuf|nø|ne|
|ar|137|0.0318|تسعة|tisʕa|tisua|
|ja|126.26075|0.0293|く|kɯ̟ᵝ|ku|
|id|121.3|0.0282|sembilan|sembilan|sembilan|
|ur|119.8|0.0278|نو|nau|nau|
|de|103.55|0.0240|neun|nɔʏ̯n|noin|
