# pasiv

## Meaning

5

## Candidates

|Word|Score|
|:-:|:-:|
|pasiv|1.217321|
|pativ|1.062902|
|fapat|1.062730|
|sipat|1.026535|
|pamiv|0.994545|
|famat|0.993347|
|pasik|0.892996|
|pagiv|0.873674|
|fapak|0.873645|
|pakiv|0.873645|

## Origins

Weight sum: 4307.36075
|ISO 639-1|Weight|Regular weight|Origin word|IPA|Loanword|
|:-:|:-:|:-:|:-:|:-:|:-:|
|zh|1020.85|0.2370|五|u²¹⁴|u|
|en|818.9|0.1901|five|faɪv|faiv|
|es|500.45|0.1162|cinco|θinko|sinko|
|hi|489.65|0.1137|पाँच|pɑ̃ːt͡ʃ|patc|
|bn|246.9|0.0573|পাঁচ|pamc|pamk|
|pt|240|0.0557|cinco|sĩku|siku|
|ru|205.75|0.0478|пять|pʲætʲ|pat|
|fr|176.95|0.0411|cinq|sɛ̃|se|
|ar|137|0.0318|خمسة|xamsa|xamsa|
|ja|126.26075|0.0293|ご|ɡo̞|go|
|id|121.3|0.0282|lima|lima|lima|
|ur|119.8|0.0278|پانچ|pɑ̃ːt͡ʃ|patc|
|de|103.55|0.0240|fünf|fʏmf|fimf|
