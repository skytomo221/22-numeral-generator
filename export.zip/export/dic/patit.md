# patit

## Meaning

8

## Candidates

|Word|Score|
|:-:|:-:|
|patit|1.449242|
|patot|1.219332|
|panit|1.116770|
|patoy|1.098460|
|patum|1.098460|
|patun|1.098412|
|patup|1.098412|
|patut|1.098412|
|patuy|1.098412|
|pasit|1.088709|

## Origins

Weight sum: 4307.36075
|ISO 639-1|Weight|Regular weight|Origin word|IPA|Loanword|
|:-:|:-:|:-:|:-:|:-:|:-:|
|zh|1020.85|0.2370|八|pä⁵⁵|pa|
|en|818.9|0.1901|eight|eɪt|eit|
|es|500.45|0.1162|ocho|ot͡ʃo|otco|
|hi|489.65|0.1137|आठ|ɑːʈʰ|at|
|bn|246.9|0.0573|আট|aʈ|at|
|pt|240|0.0557|oito|ojtu|oytu|
|ru|205.75|0.0478|восемь|vosʲɪmʲ|vosim|
|fr|176.95|0.0411|huit|wit|wit|
|ar|137|0.0318|ثمانية|θamaːnija|samaniya|
|ja|126.26075|0.0293|はち|ha̠t͡ɕi|hatci|
|id|121.3|0.0282|delapan|delapan|delapan|
|ur|119.8|0.0278|آٹھ|aːʈʰ|at|
|de|103.55|0.0240|acht|axt|axt|
