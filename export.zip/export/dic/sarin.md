# sarin

## Meaning

3

## Candidates

|Word|Score|
|:-:|:-:|
|sarin|1.469894|
|tisan|1.316973|
|sanin|1.260679|
|satin|1.249470|
|tinan|1.185890|
|sanes|1.095272|
|tisah|1.082465|
|sarih|1.072471|
|saris|1.072471|
|tiwan|1.069199|

## Origins

Weight sum: 4307.36075
|ISO 639-1|Weight|Regular weight|Origin word|IPA|Loanword|
|:-:|:-:|:-:|:-:|:-:|:-:|
|zh|1020.85|0.2370|三|sän⁵¹|san|
|en|818.9|0.1901|three|fɹiː|fri|
|es|500.45|0.1162|tres|tɾes|tres|
|hi|489.65|0.1137|तीन|t̪iːn|tin|
|bn|246.9|0.0573|তিন|tin|tin|
|pt|240|0.0557|três|tɾejs|treys|
|ru|205.75|0.0478|три|trʲi|tri|
|fr|176.95|0.0411|trois|tʁwa|trwa|
|ar|137|0.0318|ثلاثة|θalaːθah|salasah|
|ja|126.26075|0.0293|さん|sã̠ɴ|san|
|id|121.3|0.0282|tiga|tiga|tia|
|ur|119.8|0.0278|تین|tin|tin|
|de|103.55|0.0240|drei|dʁaɪ̯|drai|
