# don

## Meaning

2

## Candidates

|Word|Score|
|:-:|:-:|
|don|0.571425|
|dos|0.571420|
|dov|0.571388|
|doy|0.571364|
|tus|0.380574|
|tun|0.380431|
|tuy|0.380426|
|tuv|0.380418|
|tos|0.232785|
|vos|0.232643|

## Origins

Weight sum: 4307.36075
|ISO 639-1|Weight|Regular weight|Origin word|IPA|Loanword|
|:-:|:-:|:-:|:-:|:-:|:-:|
|zh|1020.85|0.2370|二|ɚ²¹³||
|en|818.9|0.1901|two|tuː|tu|
|es|500.45|0.1162|dos|dos|dos|
|hi|489.65|0.1137|दो|d̪oː|do|
|bn|246.9|0.0573|দুই|dui|dui|
|pt|240|0.0557|dois|dojs|doys|
|ru|205.75|0.0478|два|dva|dva|
|fr|176.95|0.0411|deux|dø|de|
|ar|137|0.0318|اثنان|iθnaːn|isnan|
|ja|126.26075|0.0293|に|ɲ̟i|ni|
|id|121.3|0.0282|dua|dua|dua|
|ur|119.8|0.0278|دو|du|du|
|de|103.55|0.0240|zwei|t͡svaɪ|tsvai|
