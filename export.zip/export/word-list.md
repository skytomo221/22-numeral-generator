# Word List

|Spell|Meaning|
|:-:|:-:|
|[ciset](./dic/ciset.md)|7|
|[don](./dic/don.md)|2|
|[focat](./dic/focat.md)|4|
|[novin](./dic/novin.md)|9|
|[pasiv](./dic/pasiv.md)|5|
|[patit](./dic/patit.md)|8|
|[rolin](./dic/rolin.md)|0|
|[sarin](./dic/sarin.md)|3|
|[siyoy](./dic/siyoy.md)|6|
|[wok](./dic/wok.md)|1|
